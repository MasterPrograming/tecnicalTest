<div class="modal" tabindex="-1" id="modalPlay" data-backdrop="static" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="title-modalPlay">Example</h5>        
      </div>
      <div class="modal-body">
        <input type="hidden" name="regId" id="regId">
        <p id="result"></p>
        <button class="btn btn-primary btn-lg text-center" id="btnTirar">Tirar</button>
      </div>      
    </div>
  </div>
</div>