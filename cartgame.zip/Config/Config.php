<?php
    //configuracion para ver errores en el navegador       
    const BASE_URL = "http://cartgame.test"; //URL DEV

    //zona horaria
    date_default_timezone_set('America/Bogota');

    //Conexion a base de datos
    const DB_HOST = "creativossoluciones.com.co";
    const DB_NAME = "creat105_cartgame";
    const DB_USER = "creat105_testcart";
    const DB_PASSWORD = '{p*#IJSkO)hh';
    const DB_CHARSET = "charset=UTF8";

    